/**
 * Data Transfer Objects.
 */
package com.testapp.service.dto;
