/**
 * JPA domain objects.
 */
package com.testapp.domain;
