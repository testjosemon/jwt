/**
 * View Models used by Spring MVC REST controllers.
 */
package com.testapp.web.rest.vm;
