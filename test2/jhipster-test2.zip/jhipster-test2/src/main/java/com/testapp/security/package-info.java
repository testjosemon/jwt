/**
 * Spring Security configuration.
 */
package com.testapp.security;
