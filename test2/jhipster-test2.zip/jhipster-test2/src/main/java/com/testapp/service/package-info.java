/**
 * Service layer beans.
 */
package com.testapp.service;
