/**
 * Spring Data JPA repositories.
 */
package com.testapp.repository;
